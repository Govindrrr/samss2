<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>
    <div class="max-w-4xl mx-auto p-6 bg-white shadow-md rounded-lg">
        <!-- Header Section -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-3xl font-semibold text-center text-gray-800">Marksheet</h2>
                <p class="text-xl text-center text-gray-600">For the Academic Year 2024-2025</p>
            </div>
            <div class="text-right">
                <p class="text-lg text-gray-800 font-medium">Roll No: <?php echo e($Marks[0]->student->roll_no); ?></p>
                <p class="text-lg text-gray-800 font-medium">Class: <?php echo e($Marks[0]->student->level->grade); ?></p>
                <p class="text-lg text-gray-800 font-medium">Section: <?php echo e($Marks[0]->student->classroom->name); ?></p>
            </div>
        </div>

        <!-- Student Info Section -->
        <div class="mb-6">
            <h3 class="text-2xl font-medium text-gray-800">Student Information</h3>
            <div class="flex gap-6">
                <div class="w-1/2">
                    <p class="text-lg text-gray-600">Name: <span
                            class="font-semibold"><?php echo e($Marks[0]->student->first_name); ?>

                            <?php echo e($Marks[0]->student->middle_name); ?> <?php echo e($Marks[0]->student->last_name); ?></span></p>
                </div>
            </div>
        </div>
        <div class="flex justify-center">
            <!-- Table for Marks -->
            <table class="w-full table-auto border-collapse">

                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Subject</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700 " colspan="2">Practical</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700 " colspan="2">Theory</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-700 " colspan="2">Obtained Mark</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-t">
                        <td class="px-4 py-2 text-sm text-gray-600"></td>
                        <td class="px-4 py-2 text-sm text-gray-600">FM</td>
                        <td class="px-4 py-2 text-sm text-gray-600">PM</td>
                        <td class="px-4 py-2 text-sm text-gray-600">FM</td>
                        <td class="px-4 py-2 text-sm text-gray-600">PM</td>
                        <td class="px-4 py-2 text-sm text-gray-600">Pr</td>
                        <td class="px-4 py-2 text-sm text-gray-600">Th</td>
                    </tr>
                    <?php $__currentLoopData = $Marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="px-4 py-2 text-sm text-gray-600"><?php echo e($mark->subject->name); ?></td>
                            <td class="px-4 py-2 text-sm text-gray-600"><?php echo e($mark->full_mark); ?></td>
                            <td class="px-4 py-2 text-sm text-gray-600"><?php echo e($mark->pass_mark); ?></td>
                            <td class="px-4 py-2 text-sm text-gray-600"><?php echo e($mark->pass_mark); ?></td>
                            <td class="px-4 py-2 text-sm text-gray-600"><?php echo e($mark->pass_mark); ?></td>
                            <td class="px-4 py-2 text-sm text-red-600<?php echo e($mark->marks > $mark->pass_mark ? 'text-red-500' : ''); ?> "><?php echo e($mark->marks); ?></td>
                            <td class="px-4 py-2 text-sm text-gray-600"><?php echo e($mark->marks); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="px-4 py-2 text-sm text-gray-600 ">Total = <?php echo e($total); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-600 "> GPA = <?php echo e($gpa); ?></td>
                        <td class="px-4 py-2 text-sm text-gray-600 ">result =
                            <?php if($result == 1): ?>
                            Pass
                            <?php else: ?>
                                 Fail                  
                            <?php endif; ?></td>
                        <td class="px-4 py-2 text-sm text-gray-600 ">absent = <?php echo e($total); ?></td>
                   </tr>
                    
                </tbody>
            </table>



        </div>
</body>

</html>
<?php /**PATH E:\School_project\samss2\resources\views/studentresult.blade.php ENDPATH**/ ?>