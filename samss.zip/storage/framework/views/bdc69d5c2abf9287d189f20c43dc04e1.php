<div>
    <?php echo e($this->table); ?>

 </div><?php /**PATH E:\School_project\samss2\resources\views/livewire/result-page.blade.php ENDPATH**/ ?>