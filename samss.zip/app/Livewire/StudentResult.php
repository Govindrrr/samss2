<?php

namespace App\Livewire;

use Livewire\Component;

class StudentResult extends Component

{
    public function render()
    {
        return view('livewire.student-result');
    }
}
