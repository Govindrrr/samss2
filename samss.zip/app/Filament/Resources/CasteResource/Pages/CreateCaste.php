<?php

namespace App\Filament\Resources\CasteResource\Pages;

use App\Filament\Resources\CasteResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCaste extends CreateRecord
{
    protected static string $resource = CasteResource::class;
}
