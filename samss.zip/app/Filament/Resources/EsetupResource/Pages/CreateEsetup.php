<?php

namespace App\Filament\Resources\EsetupResource\Pages;

use App\Filament\Resources\EsetupResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEsetup extends CreateRecord
{
    protected static string $resource = EsetupResource::class;
}
