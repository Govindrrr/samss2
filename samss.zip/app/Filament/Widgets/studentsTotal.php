<?php
 
namespace App\Filament\Widgets;

use App\Models\Student;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
 
class studentsTotal extends BaseWidget
{
    protected function getStats(): array

    {
        $totalStudent = Student::count();
        return [
            Stat::make('Total Students', $totalStudent),
            Stat::make('Bounce rate', '21%'),
            Stat::make('Staff And Teachers', '57'),
        ];
    }
}