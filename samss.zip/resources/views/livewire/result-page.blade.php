<div>
    {{$this->table}}
 </div>